

#include <stdio.h>
#include <stdlib.h>
#include "bmp_estructure.h"
int main(){
    char nombre[100]="D:/Users/Nessa/Desktop/universidad/Embebidos 4/Lab1 Funcional/Laboratorio1/Labtry1/imagen.bmp";
    FILE* fichero;
    uint16_t type;
    bmpFileHeader header;
    bmpInfoHeader Info;
    unsigned char *img_old;
    unsigned char *img_new;

    while (1) {

        printf("Cargando imargen BMP\n");
        fichero = fopen(nombre, "rb");
        if (fichero==NULL){
            printf("Imagen no encontrada\n");
            fclose(fichero);
            return 1;
        }
        fread(&type,2,1,fichero);
        if (type!=0x4D42){
            printf("Formato de imagen diferente a BMP\n");
            fclose(fichero);
            return 1;
        }
        fread(&header,sizeof (bmpFileHeader),1,fichero);
        fread(&Info,sizeof (bmpInfoHeader),1,fichero);

        if (Info.bpp != 24) {
            printf("Solo se soportan imágenes BMP de 24 bits por píxel.\n");
            fclose(fichero);
            return 1;
        }

        img_old=(unsigned char*) malloc(Info.imgsize);
        img_new=(unsigned char*) malloc(Info.imgsize);
        fseek(fichero, header.offset, SEEK_SET);    /* Posición */
        fread(img_old, Info.imgsize, 1, fichero);

        fclose(fichero);

        char entrada[100];
        do{
            printf("Menu de aplicacion en C para archivos BMP.\nEn esta aplicacion podra seleccionar 2 opciones.\n\n");
            printf("1. Escala de grises, con esta opción se procesa la imágen para convertirla en escala "
                   "de grises, una vez convertida esta queda guardada como un nuevo archivo BMP en disco.\n\n");
            printf("2. Convolución, con esta opción se procesa la imagen realizando una operación de "
                   "convolución utilizando un KERNEL (matriz de 3x3 ) que sera solicitado al escoger "
                   "esta opción. Una vez convertida la imagen, esta queda guardada como un nuevo "
                   "archivo BMP en disco.\n\n");
            printf("3. Cerrar aplicacion.\n\n-> ");
            scanf("%s",entrada);

        }while (entrada[0]!='1'&&entrada[0]!='2'&&entrada[0]!='3');
        if(entrada[0]=='1'){
            uint32_t i,j;
            for(i=0;i<Info.height;i++){
                for(j=0;j<Info.width;j++){
                    unsigned media=(img_old[3*(j+i*Info.width)]+img_old[3*(j+i*Info.width)+1]+img_old[3*(j+i*Info.width)+2])/3;
                    img_new[3*(j+i*Info.width)]=media;
                    img_new[3*(j+i*Info.width)+1]=media;
                    img_new[3*(j+i*Info.width)+2]=media;

                }
            }
            char nombre2[65] ="EscalaGrises.bmp";
            FILE *f2;
            f2=fopen(nombre2,"wb+");
            if (f2==NULL){
                printf("Archivo Imposible de crear.\n");
                return 1;
            }
            fwrite(&type,sizeof(type),1,f2);
            fwrite(&header,sizeof(header),1,f2);
            fwrite(&Info,sizeof(Info),1,f2);
            fseek(fichero, header.offset, SEEK_SET);    /* Posición */
            fwrite(img_new,Info.imgsize,1,f2);
            fclose(f2);
            free(img_new);
            free(img_old);
            printf("Imagen guardada con exito como EscalaGrises.bmp.\n\n");
        }else if(entrada[0]=='2'){
            int kernel[3][3] = {
                {-1, 0, 1},
                {-2, 0, 2},
                {-1, 0, 1}
            };
            uint32_t i,j;
            printf("Ingrese la matriz de convolucion, esta sera una matriz de 3*3.\n\n");
            for(i=0;i<3;i++){
                for(j=0;j<3;j++){
                    printf("\nPosicion %d,%d-> ",i,j);
                    scanf("%d",&kernel[i][j]);
                }
            }
            printf("\nLa matriz de convolucion ingresada es:");
            printf("\n||%d|%d|%d||\n||%d|%d|%d||\n||%d|%d|%d||\n\n",
                    kernel[0][0],kernel[0][1],kernel[0][2],
                    kernel[1][0],kernel[1][1],kernel[1][2],
                    kernel[2][0],kernel[2][1],kernel[2][2]
                    );

            for(int y=1;y<(Info.height-1);y++){
                for(int x=1;x<(Info.width-1);x++){
                    for (int channel = 0; channel < 3; channel++) { // Aplicar a cada canal (R, G, B)
                        int value = 0;
                        for (int ky = -1; ky <= 1; ky++) {
                            for (int kx = -1; kx <= 1; kx++) {
                                value += img_old[(y + ky) * Info.width * 3 + (x + kx) * 3 + channel] * kernel[ky + 1][kx + 1];
                            }
                        }
                        if (value < 0) value = 0;
                        if (value > 255) value = 255;
                        img_new[y * Info.width * 3 + x * 3 + channel] = (unsigned char)value;
                    }

                }
            }
            char nombre2[65] ="Convolucion.bmp";
            FILE *f2;
            f2=fopen(nombre2,"wb+");
            fwrite(&type,sizeof(type),1,f2);
            fwrite(&header,sizeof(header),1,f2);
            fwrite(&Info,sizeof(Info),1,f2);
            fseek(fichero, header.offset, SEEK_SET);    /* Posición */
            fwrite(img_new,Info.imgsize,1,f2);
            fclose(f2);
            free(img_new);
            free(img_old);
            printf("Imagen guardada con exito como Convolucion.bmp.\n\n");
        }else{
            break;
        }

    }
    return 0;
}
